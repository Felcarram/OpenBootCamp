package com.company;

import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {
        Coche miCoche = new Coche();
        miCoche.AumentarPuertas();
        miCoche.AumentarPuertas();
        miCoche.AumentarPuertas();
        miCoche.AumentarPuertas();

        System.out.println(miCoche.puertas);

    }

    public static int suma(int a, int b) {
        return a + b;
    }

}

class Coche {
    public int puertas = 0;

    public void AumentarPuertas() {
        this.puertas++;
    }
}