package com.company;

import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {
        int resultado;
        resultado = suma(10,30,40 );

        System.out.println(resultado);

    }

    public static int suma(int a, int b, int c) {
        return a + b + c;
    }

